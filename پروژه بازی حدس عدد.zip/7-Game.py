
#in code tavasote Amir Hossein Shirazi baratye tamrine shomare 7 pythone moqadamati neveshte shode ast

import random

x = 0
y = 99
hads = random.randint(x, y)

print(hads)

b = input('status: ')
t=['b','d','k']
while b != 'd':
    if b == 'b':
        x = hads
    elif b == 'k':
        y = hads
    elif b != t:
        print('vorodi eshtebahe!')
        quit()
    hads = random.randint(x, y)
    print(hads)
    b = input('status: ')

print('Dorost hads zadiiii! mashaalaaaa!')

